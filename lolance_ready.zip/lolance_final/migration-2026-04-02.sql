-- LOLance migration 2026-04-02
-- Run this on your existing DB (safe to run multiple times)

USE lolance;

-- ── Rate limiting for login ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS login_attempts (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(255) NOT NULL COMMENT 'email or IP',
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_identifier_time (identifier, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Multi-currency crypto deposits ────────────────────────────────
ALTER TABLE crypto_deposits
    ADD COLUMN IF NOT EXISTS currency     VARCHAR(10)    NOT NULL DEFAULT 'USDT' AFTER user_id,
    ADD COLUMN IF NOT EXISTS amount_native DECIMAL(20,8) NOT NULL DEFAULT 0      AFTER currency,
    ADD COLUMN IF NOT EXISTS usd_rate     DECIMAL(16,4)  NOT NULL DEFAULT 1.0000 AFTER amount_native,
    ADD COLUMN IF NOT EXISTS admin_verified BOOLEAN      NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS admin_note   VARCHAR(255)   NULL;

-- ── Legal acceptances (idempotent) ───────────────────────────────
CREATE TABLE IF NOT EXISTS legal_acceptances (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NOT NULL,
    doc_type      ENUM('terms','privacy') NOT NULL,
    doc_version   VARCHAR(30) NOT NULL,
    accepted_ip   VARCHAR(45),
    user_agent    VARCHAR(255),
    accepted_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_doc_version (user_id, doc_type, doc_version),
    KEY idx_user_doc (user_id, doc_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Drop cached balance from users (single source of truth = transactions) ──
-- ALTER TABLE users DROP COLUMN IF EXISTS balance; -- optional, keep for now
